import AppRoutes from "./routes/routes";

export function App() {
  return <AppRoutes />;
}

export default App;
